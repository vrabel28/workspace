package service;

import data.Employee;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SalaryService
{

    public List <String> salaryList = new ArrayList <> ();
    public List <Employee> employees = new ArrayList <> ();
    public int finalSalary;
    public Scanner scan;


    public int calculateAvarageSalary (String line, int skipRow)
    {
        if (skipRow != 1)
        {

            Integer sumSalary = 0;
            salaryList = getSalaryList (line, skipRow);
            for (String unit:salaryList)
            {
                sumSalary += new Integer (Integer.parseInt (unit));
            }
            if (!salaryList.isEmpty ())
            {
                finalSalary = sumSalary / salaryList.size ();
            }
            skipRow++;
        }
        return finalSalary;
    }

    public List <Employee> correctManagerSalary (String filename, int skipRow)
    {
        int maxSalaryManager = 0;
        int minSalaryManager = 0;
        int avgSalary = 0;
        List <Employee> wrongManagerList = new ArrayList <> ();
        try
        {
            scan = new Scanner (new File (filename));
        } catch (FileNotFoundException e)
        {
            e.printStackTrace ();
        }
        while (scan.hasNextLine ())
        {
            String line = scan.nextLine ();

            if (line.length () > 9)
            {
                avgSalary = calculateAvarageSalary (line, skipRow);
                // get users to employees list
                EmployeeService employeeService = new EmployeeService ();
                employees = employeeService.getEmployeeFromLine (line, employees);
                skipRow++;
            }
        }

        minSalaryManager = (int) ((avgSalary * 0.2) + avgSalary);
        maxSalaryManager = (int) ((avgSalary * 0.5) + avgSalary);
        employees.remove (0);
        for (Employee employee:employees)
        {
            if (employee.getManagerId ().length () > 6)
            {

                int employeeSalary = Integer.parseInt (employee.getSalary ());

                if (employeeSalary > minSalaryManager
                        && employeeSalary < maxSalaryManager)
                {
                    continue;
                }
                else
                {
                    int difference1 = 0;
                    int difference = 0;
                    difference = employeeSalary - minSalaryManager;
                    difference1 = maxSalaryManager - employeeSalary;
                    if (difference > 0)
                    {
                        employee.setDifference (difference);
                    }

                    if (difference1 > 0)
                    {
                        employee.setDifference (difference1);
                    }
                    wrongManagerList.add (employee);
                }

            }
            else
            {
                System.out.println ("User is not manager");
                continue;
            }
        }
        return wrongManagerList;

    }

    public List < String > getSalaryList (String line, int skipRow)
    {
        List < String > values = new ArrayList < String > ();
        String salary = "";
        Integer price = 0;

        try (Scanner rowScanner = new Scanner (line))
        {
            rowScanner.useDelimiter (",");

            while (rowScanner.hasNext ())
            {
                values.add (rowScanner.next ());
            }
        }
        if (skipRow != 1)
        {
            if (line.length () > 9)
            {
                price = Integer.parseInt (values.get (3));


                if (values != null && price != null)
                {
                    salary = values.get (3);
                    if (salary != null)
                    {
                        System.out.println ("input salary value:" + salary);
                        salaryList.add (salary);
                    }
                }
            }
            skipRow++;
        }
        return salaryList;
    }


}
