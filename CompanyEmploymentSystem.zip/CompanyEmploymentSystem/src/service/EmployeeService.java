package service;

import data.Employee;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class EmployeeService
{

    public int lineNumber = 1;
    public List <Employee> employees = new ArrayList <> ();
    public Scanner scan;
    public  List<Employee> employeeFromLine = new ArrayList<>();

    public void categorizedEmployments (String filename, int skipRow)
    {
        SalaryService salaryService = new SalaryService ();
        List<Employee> managerList = new ArrayList<>();

        try
        {
            scan = new Scanner (new File (filename));
            while (scan.hasNextLine ())
            {
                String line = scan.nextLine ();
                if (skipRow != 1)
                {
                    employeeFromLine = getEmployeeFromLine(line,employees);
                    salaryService.getSalaryList (line, skipRow);
                    System.out.println ("line " + lineNumber + " :" + line);
                    lineNumber++;
                    salaryService.calculateAvarageSalary (line, skipRow);
                    skipRow++;

                }
                skipRow++;
            }
            for (Employee employee :employeeFromLine)
            {
                if(employee.getManagerId().length() > 1){
                    managerList.add(employee);
                }
                if(managerList.size() > 4){
                    System.out.println("At the compay is lot of managers");
                }

            }
        }
        catch (FileNotFoundException e)
        {
            System.out.println ("Input file " + filename + " does not exist");
        }
        finally
        {
            scan.close ();
            System.out.println ("Finish reading and calculate from file");
        }
    }

    public List <Employee> getEmployeeFromLine (String line, List<Employee>employeeList)
    {
        List < String > values = new ArrayList < String > ();
        Scanner rowScanner = new Scanner (line);
        try
        {
            rowScanner.useDelimiter (",");

            while (rowScanner.hasNext ())
            {
                values.add (rowScanner.next ());
            }

            Employee employee = new Employee ();
            String id = values.get (0);
            employee.setEmployeeId (id);
            String firstName = values.get (1);
            employee.setFirstName (firstName);
            String lastName = values.get (2);
            employee.setLastName (lastName);
            String salary = values.get (3);
            employee.setSalary (salary);
            String managerId = values.get (4);
            employee.setManagerId (managerId);
            employeeList.add (employee);
        }
        finally
        {
            rowScanner.close ();
            return employeeList;
        }
    }

}
