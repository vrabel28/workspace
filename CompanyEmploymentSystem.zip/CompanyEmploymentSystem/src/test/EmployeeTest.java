//package test;
//
//import data.Employee;
//import org.junit.Test;
//
//import static org.junit.Assert.assertEquals;
//
//public class EmployeeTest {
//
//    @Test
//  public  void testPerson_name() {
//        Employee employee = new Employee(1, "12345AB","Richard");
//        String displayName = employee.getName();
//        assertEquals("Richard", displayName);
//    }
//
//    @Test
//    public  void testPerson_id() {
//        Employee employee = new Employee(1, "12345AB","Richard");
//        int user_id = employee.getUserId();
//        assertEquals(1, user_id);
//    }
//
//    @Test
//    public  void testPerson_guiid() {
//        Employee employee = new Employee(1, "12345AB","Richard");
//        String user_guiid = employee.getUserGUID();
//        assertEquals("12345AB", user_guiid);
//    }
//}
