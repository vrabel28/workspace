package repository;

import data.Employee;

import java.sql.SQLException;
import java.util.ArrayList;


public interface EnployeeRepository {

    public Employee addUser(Employee employee) throws SQLException;
    public void selectUsers() throws SQLException;
    public Employee deleteUser(Employee employee) throws SQLException;
    public String deleteAllUsers() throws SQLException;
    public ArrayList<Employee> getUsersList();

}
