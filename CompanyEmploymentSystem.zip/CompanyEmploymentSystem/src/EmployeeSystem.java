import data.Employee;
import service.EmployeeService;
import service.SalaryService;
import java.io.IOException;
import java.util.List;

public class EmployeeSystem
{


    public static void main (String[]args) throws IOException
    {
        EmployeeService employeeService = new EmployeeService();
        SalaryService salaryService = new SalaryService ();
        List <Employee> managerList = salaryService.correctManagerSalary ("EmpList.csv", 1);
        employeeService.categorizedEmployments("EmpList.csv",1);

        for (Employee manager:managerList)
        {
            System.out.println ("Managers who does not have correct salary:" +
                    manager.getFirstName () + " " +
                    manager.getLastName () + " difference: " +
                    manager.getDifference ());
        }

    }
}
